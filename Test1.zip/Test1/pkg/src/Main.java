import com.sql.*;
import com.frame.*;
public class Main{
    public static void main(String[] args){
        //Renewal r=new Renewal();
        //r.query();
        LoadingFrame l=new LoadingFrame();
    }
}
