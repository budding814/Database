package com.use;

import javax.swing.*;

public class query_JFrame extends JFrame {
    public query_JFrame(){

    }
}
