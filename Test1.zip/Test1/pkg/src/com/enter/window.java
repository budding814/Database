package com.enter;
import com.frame.enterFrame;
public class window {
    public static void main(String[] args){
        new enterFrame();
    }
}
